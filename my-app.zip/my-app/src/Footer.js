import React from 'react';

function Footer() {
    return (
        <div>
            <h1 className="bg-gray-800 text-white p-4">footer page</h1>
            
        </div>
    );
}

export default Footer;